﻿using UnityEngine;
using UnityEngine.EventSystems;
using DG.Tweening;

public class CalendarPageScroll : MonoBehaviour,IBeginDragHandler,IDragHandler,IEndDragHandler
{
    public delegate void PageScrollEnd(int index);
    public static event PageScrollEnd pageScrollEnd;

    int curIndx;
    void Start()
    {
       
    }
    

    public void OnBeginDrag(PointerEventData eventData)
    {
        
    }

    public void OnDrag(PointerEventData eventData)
    {
        transform.localPosition = new Vector3(transform.localPosition.x + eventData.delta.x, transform.localPosition.y, 0);
        int perItemX = (int)CalenderController.instance.PerPageWidth;
        if (transform.localPosition.x > 0.3f* perItemX - perItemX/2)
        {
            transform.localPosition = new Vector3(0.3f * perItemX - perItemX / 2, transform.localPosition.y, 0);
        }
        if (transform.localPosition.x<-(2*perItemX+0.3f*perItemX) - perItemX / 2)
        {
            transform.localPosition = new Vector3(-(2 * perItemX + 0.3f * perItemX) - perItemX / 2, transform.localPosition.y, 0);
        }
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        int perItemX = (int)CalenderController.instance.PerPageWidth;
        int tempIndex = -((int)transform.localPosition.x - perItemX) / perItemX - 1;
        Debug.Log("curIndx:" + curIndx);
        Debug.Log("tempIndeX:" + tempIndex);
        if (tempIndex != curIndx && CalenderController.instance.PageNum > 3)
        {
            curIndx = tempIndex;
            //页面接续
            if (curIndx == 0)
            {
                CalenderController.instance.CurPageIndex = Mathf.Max(0, CalenderController.instance.CurPageIndex - 1);
                Transform t = transform.GetChild(2);
                t.transform.SetAsFirstSibling();
                transform.localPosition = new Vector3(transform.localPosition.x - perItemX, transform.localPosition.y, 0);
                t.GetComponent<CalendarPage>().LoadItems(CalenderController.instance.CurPageIndex - 1);
            }
            else if (curIndx == 2)
            {
                CalenderController.instance.CurPageIndex = Mathf.Min(CalenderController.instance.PageNum - 1, CalenderController.instance.CurPageIndex + 1);
                Transform t = transform.GetChild(0);
                t.SetAsLastSibling();
                transform.localPosition = new Vector3(transform.localPosition.x + perItemX, transform.localPosition.y, 0);
                t.GetComponent<CalendarPage>().LoadItems(CalenderController.instance.CurPageIndex + 1);
            }
            Debug.Log("真实页面:" + CalenderController.instance.CurPageIndex);
            if (pageScrollEnd != null)
            {
                pageScrollEnd(CalenderController.instance.CurPageIndex);
            }
            transform.DOLocalMoveX(-perItemX - perItemX / 2.0f, 0.5f);
        }
        else
        {
            transform.DOLocalMoveX(-perItemX * CalenderController.instance.CurPageIndex - perItemX / 2.0f, 0.5f);
        }
    }
}
