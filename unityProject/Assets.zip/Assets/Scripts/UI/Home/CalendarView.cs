﻿using DataMgr;
using GameMgr;
using Helper;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CalendarView : MonoBehaviour
{
    public Button BtnBack;
    public Button BtnDelete;
    public Button BtnDefault;
    public RectTransform ListContent;
    public Text TxtPage;

    //当前页面的人物列表
    //private List<CalenderItem> personList = new List<CalenderItem>();

    private List<CalendarPage> pageList = new List<CalendarPage>();
    private float PageWidth;
    private float PageHeight;

    void Start()
    {
        AddBtnListener();
        AddEventListener();
        InitPageContent();
        InitPageList();
        SetPageText();
        //RefreshList();
        //SwitchDelBtn(true);
    }

    private void InitPageContent()
    {
        CanvasScaler canvas = GameManager.instance.GetCanvas().GetComponent<CanvasScaler>();
        float canvasScaler = canvas.matchWidthOrHeight;
        Vector2 referenceResolution = canvas.referenceResolution;
        if (canvasScaler == 1)//高适配
        {
            PageHeight = referenceResolution.y;
            PageWidth = 1.0f * Screen.width / Screen.height * referenceResolution.y;
        }
        else
        {
            PageWidth = referenceResolution.x;
            PageHeight = 1.0f * 2048 / (Screen.width / Screen.height);
        }

        CalenderController.instance.PerPageWidth = PageWidth;
        
        int pageCount = Mathf.Min(CalenderController.instance.PageNum, 3);
        ListContent.sizeDelta = new Vector2(pageCount * PageWidth, PageHeight);

        for (int i = 0; i < pageCount; i++)
        {
            UIHelper.instance.LoadPrefab("Prefabs/calendar|calendar_page", ListContent, Vector3.zero, Vector3.one, false);
        }
        LayoutRebuilder.ForceRebuildLayoutImmediate(ListContent);
    }

    //初始化页面列表
    private void InitPageList()
    {
        int endPage = Mathf.Min(CalenderController.instance.PageNum, 3);
        for (int i = 0; i < endPage; i++)
        {
            CalendarPage page = ListContent.GetChild(i).GetComponent<CalendarPage>();
            page.LoadItems(i);
        }
    }
    /*
    private void GetPageList()
    {
        CalenderController.instance.PageList.Clear();
        if (CalenderController.instance.CurPageIndex == 0)
        {
            for (int i = 0; i < ListContent.childCount; i++)
            {
                Transform item = ListContent.GetChild(i);
                CalendarPage page = item.GetComponent<CalendarPage>();
                //当前是第一页
                page.LoadItems(i);
                CalenderController.instance.PageList.Add(page);
            }
        }
        else if (CalenderController.instance.CurPageIndex == CalenderController.instance.PageNum - 1)
        {
            int j = 0;
            for (int i = ListContent.childCount-1; i >= 0; i--)
            {
                Transform item = ListContent.GetChild(i);
                CalendarPage page = item.GetComponent<CalendarPage>();
                //当前是第一页
                page.LoadItems(CalenderController.instance.CurPageIndex-j);
                CalenderController.instance.PageList.Add(page);
                j++;
            }
        }
        else
        {
            for (int i = 0; i < ListContent.childCount; i++)
            {
                Transform item = ListContent.GetChild(i);
                CalendarPage page = item.GetComponent<CalendarPage>();
                //当前是第一页
                page.LoadItems(i);
                CalenderController.instance.PageList.Add(page);
            }
        }
    }
    */

    private void SetPageText()
    {
        TxtPage.text = (CalenderController.instance.CurPageIndex + 1).ToString() + " / " + CalenderController.instance.PageNum.ToString();
    }

    private void AddEventListener()
    {
        CalenderController.deleteItemComplete += DeleteItemComplete;
    }

    private void RemoveEventListener()
    {
        CalenderController.deleteItemComplete -= DeleteItemComplete;
    }

    public void RefreshList()
    {
        //StartCoroutine(LoadPersonList(CalenderController.instance.GetPersonList()));
    }

    private void AddBtnListener()
    {
        BtnBack.onClick.AddListener(delegate {
            Destroy(gameObject);
        });

        BtnDelete.onClick.AddListener(delegate {
            /*
            ShowDeleteBtn(true);
            SwitchDelBtn(false);
            */
        });

        BtnDefault.onClick.AddListener(delegate {
            /*
            ShowDeleteBtn(false);
            SwitchDelBtn(true);
            */
        });
    }
    /*
    IEnumerator LoadPersonList(List<string> pathList)
    {
        Debug.Log(pathList.Count);
        int index = 0;
        while (index < pathList.Count)
        {
            UIHelper.instance.LoadPrefabAsync("Prefabs/calendar|calendar_item", ListContent, Vector3.zero, Vector3.one, false, null, (item) => {
                Debug.Log(pathList[index]);
                PartDataWhole whole = PersonManager.instance.DeserializePerson(pathList[index]);
                item.name = pathList[index];
                CalenderItem calenderItem = item.GetComponent<CalenderItem>();
                calenderItem.Init(index,pathList[index],whole);
                personList.Add(calenderItem);
                index += 1;
            });
            yield return new WaitForSeconds(0.05f);
        }
    }
    */

    /*
    public void ShowDeleteBtn(bool show)
    {
        for (int i = 0; i < personList.Count; i++)
        {
            personList[i].ShowDelete(show);
        }
    }
    */

    /*
    public void SwitchDelBtn(bool isDelete)
    {
        BtnDelete.gameObject.SetActive(isDelete);
        BtnDefault.gameObject.SetActive(!isDelete);
    }
    */

    public void DeleteItemComplete(CalenderItem deleteItem)
    {/*
        if (deleteItem != null)
        {
            personList.Remove(deleteItem);
            DestroyImmediate(deleteItem.gameObject);
        }*/
    }

    private void OnDestroy()
    {
        RemoveEventListener();
    }
}
