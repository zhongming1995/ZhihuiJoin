﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using GameMgr;

public class ColorToggleCtrl : MonoBehaviour
{
    public List<Toggle> toggleLst = new List<Toggle>();
    ToggleGroup tg;
    JoinMainView joinMainView;
    // Use this for initialization
    void Start()
    {
        joinMainView = transform.GetComponentInParent<JoinMainView>();
        tg = transform.GetComponent<ToggleGroup>();
        int count = transform.childCount;
        for (int i = 0; i < count; i++)
        {
            int index = i;
            Toggle t = transform.GetChild(i).GetComponent<Toggle>();
            t.group = tg;
            if (i == 2)
            {
                t.isOn = true;
            }
            else
            {
                t.isOn = false;
            }
            t.onValueChanged.AddListener(delegate
            {
                SelectOneColor(t.isOn,index);
            });
            toggleLst.Add(t);
        }
        toggleLst[2].isOn = true;
    }

    private void SelectOneColor(bool isOn,int index) {
        if (isOn)
        {
            Debug.Log(index);
            joinMainView.SelectColor(GameManager.instance.ColorList[index]);
            joinMainView.ShowBackBtn(false);
        }
    }

    // Update is called once per frame
    void Update()
    {

    }
}
