﻿using System;
namespace UI.Data
{
    [Serializable]
    public class PersonData
    {
        public PersonData()
        {

        }
    }
}